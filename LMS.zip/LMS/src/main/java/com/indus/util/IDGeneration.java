package com.indus.util;

import java.util.Random;

public class IDGeneration {
	int id=0;
	public int patronId()
	{
		String pid="333";
		Random r=new Random();
		for(int i=0;i<6;i++)
		{
			pid+=r.nextInt(9);
		}
		//System.out.println(pid);
		id=Integer.parseInt(pid);
		return id;
		
	}
	public int adminId()
	{
		String aid="111";
		Random r=new Random();
		for(int i=0;i<6;i++)
		{
			aid+=r.nextInt(9);
		}
		//System.out.println(aid);
		id=Integer.parseInt(aid);
		return id;	
	}
/**
 * 
 * @return
 */
	public int librarianId()
	{
		String lid="222";
		Random r=new Random();
		for(int i=0;i<6;i++)
		{
			lid+=r.nextInt(9);
		}
		//System.out.println(lid);
		id=Integer.parseInt(lid);
		return id;	
	}
	public int bookId()
	{
		String bid="444";
		Random r=new Random();
		for(int i=0;i<6;i++)
		{
			bid+=r.nextInt(9);
		}
		//System.out.println(bid);
		id=Integer.parseInt(bid);
		return id;	
	}
	public int magazineId()
	{
		String mid="555";
		Random r=new Random();
		for(int i=0;i<6;i++)
		{
			mid+=r.nextInt(9);
		}
		//System.out.println(mid);
		id=Integer.parseInt(mid);
		return id;	
	}
	public int microfilmId()
	{
		String mfid="666";
		Random r=new Random();
		for(int i=0;i<6;i++)
		{
			mfid+=r.nextInt(9);
		}
		System.out.println(mfid);
		id=Integer.parseInt(mfid);
		return id;	
	}

}
