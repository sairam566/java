package com.indus.util;

public class CalculateFine {
	
	public static double getFine(int days)
	{
		double fine=0.0;
		fine=2*days;
		return fine;
		
	}

}
