package com.indus.util;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class GetCurrentDateTime {
	
	 private static final DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	 
	 public static Date getCurrentDate()
	 {
		 Date date = new Date();
	      
		return date ;	 
	 }
	 
	 public static Date getDueDate(int days)
	 {
		 Date date = new Date();
			
				Date dueDate = addDays(date, days);
				return dueDate ;
	
	 }
	 public static Date addDays(Date date, int days) {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			cal.add(Calendar.DATE, days);
			return cal.getTime();
		}
	 public static Date getDueHours(int hours)
	 {
		 Date date = new Date();
			
				Date dueDate = addHours(date,hours );
				return dueDate ;
	
	 }
	 public static Date addHours(Date date, int hours) {
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			cal.add(Calendar.HOUR, hours);
			return cal.getTime();
		}
	 public static int overDueDays(Date returnDate,Date dueDate)
	 {
		 
		 long diff = returnDate.getTime() - dueDate.getTime();
			long diffDays = diff / (24 * 60 * 60 * 1000);
		return (int) diffDays;
		 
	 }
	 public static int overDueHours(Date returnDate,Date dueDate)
	 {
		 
		 long diff = returnDate.getTime() - dueDate.getTime();
		 long diffHours = diff / (60 * 60 * 1000) % 24;
			
		return (int) diffHours;
		 
	 }
	 public static Date getDate(String dop)
	 {
		 Date date=null;
		 try {
			date=sdf.parse(dop);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
		 
	 }
}
