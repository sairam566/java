package com.indus.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil 
{
 static SessionFactory sessionFactory;
static Session session;
	
	public static Session buildSession()
	{
		if(sessionFactory==null)
		{
		
		Configuration c= new Configuration().configure("hibernate.cfg.xml");
		
		ServiceRegistry s =new StandardServiceRegistryBuilder().applySettings(c.getProperties()).build();
		
		 sessionFactory=	c.buildSessionFactory(s);
		 session = sessionFactory.openSession();
		return session;
		}
		else
			return sessionFactory.openSession();
	}
	
	
	
	
}
