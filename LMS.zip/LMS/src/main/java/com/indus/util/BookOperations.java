package com.indus.util;

public class BookOperations 
{
	public static int getDays(String assetType)
	{
		if("Book".equals(assetType))
		{
			return 21;
		}
		else if("Magzine".equals(assetType))
		{
			return 2;
		}
		else
		{
			return 1;
		}
	}
}
