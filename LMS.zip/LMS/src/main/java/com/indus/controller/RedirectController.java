package com.indus.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;

import com.indus.model.Asset;
import com.indus.model.IssueLibCard;

@Controller
public class RedirectController 
{

	@RequestMapping(value="AddAsset",method=RequestMethod.GET)
	public ModelAndView redirectToAddAsset()
	{
		return new ModelAndView("AddAsset","addasset",new Asset());
	}
	@RequestMapping(value="edit",method=RequestMethod.GET)
	public ModelAndView redirectToEditAsset()
	{
		return new ModelAndView("edit");
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public ModelAndView redirectToDelAsset()
	{
		return new ModelAndView("edit");
	}
	
	@RequestMapping(value="IssueLibrarycard",method=RequestMethod.GET)
	public ModelAndView redirectToIssuCard()
	{
		
		return new ModelAndView("IssueLibrarycard","issuelibcard", new IssueLibCard());
	}
	@RequestMapping(value="issuebook",method=RequestMethod.GET)
	public ModelAndView redirectToIssuBook()
	{
		return new ModelAndView("IssueBook");
	}
//	@RequestMapping(value="editAsset",method=RequestMethod.GET)
//	public ModelAndView redirectToAssetEdit()
//	{
//		return new ModelAndView("edit");
//	}
	
}
