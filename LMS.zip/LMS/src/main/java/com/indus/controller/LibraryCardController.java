package com.indus.controller;

import java.sql.Date;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.indus.model.IssueLibCard;
import com.indus.service.LibraryCardService;


@Controller
public class LibraryCardController 
{

	@Autowired
	LibraryCardService libraryCardService;
	
	
	@RequestMapping(value="/issuecard" )
	public ModelAndView issueCard(@Valid @ModelAttribute("issuelibcard") IssueLibCard issueLibCard,BindingResult bindingResult,HttpServletRequest request)
	{
		String getDate=request.getParameter("dateOfBirth");
		
		System.out.println("|"+getDate+"|date String");
		
		System.out.println("Role |"+issueLibCard.getUserType()+"|");
		System.out.println(issueLibCard.getUserType().isEmpty());
		
		if((getDate.trim().isEmpty() || getDate==null))
		{
			return new ModelAndView("IssueLibrarycard","datemessage","Date Not selected");
		}
		if(issueLibCard.getUserType().isEmpty())
		{
			return new ModelAndView("IssueLibrarycard","rolemessage","role Not selected");
		}
		
		if(bindingResult.getErrorCount()>1)
		  {
			  return new ModelAndView("IssueLibrarycard");
		  }	
		
		else
		{

		System.out.println("inside IssueLibrary controller");
		System.out.println(issueLibCard.getDateOfBirth()+"  ----->dateof birth before");
		
		//converting string into sql date  
		//System.out.println(date); 
		//java.util.Date date=Date.valueOf(request.getParameter("date"));
		issueLibCard.setDateOfBirth(Date.valueOf(getDate));
	   // System.out.println(issueLibCard.getDateOfBirth()+"dateof birth after");
	    
		boolean flag=  libraryCardService.putLibraryCard(issueLibCard);
	    
		return new ModelAndView("search");
		}
	}
}
