package com.indus.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.indus.model.Asset;
import com.indus.service.ListAssetService;

@Controller
public class StudentController 
{
	
	
	@Autowired
	ListAssetService listAssetService;

	//----------- Redirect Methods------------------
	/*This Methods is used to redirect the request from controller to with in the controller*/

	@RequestMapping(value="assetstaken",method=RequestMethod.GET)
	public ModelAndView goToProfile()
	{
		
		return new ModelAndView("studentbooklist");
	}
	
	@RequestMapping(value="homepage",method=RequestMethod.GET)
	public ModelAndView goToHome()
	{
		List<Asset> listAssets=listAssetService.listAssets();
		ModelAndView view= new ModelAndView("studentpage");
		view.addObject("assetlist", listAssets);
		return view;
	}
	
}
