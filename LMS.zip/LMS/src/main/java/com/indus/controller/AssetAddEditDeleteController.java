package com.indus.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.indus.model.Asset;
import com.indus.model.AssetList;
import com.indus.service.AssetAddEditDeleteService;

@Controller
public class AssetAddEditDeleteController 
{
	@Autowired
	AssetAddEditDeleteService assetAddEditDeleteService;
	
	@RequestMapping(value="/addassetToDB",method=RequestMethod.POST)
	public ModelAndView addAsset(@Valid @ModelAttribute("addasset")Asset assetObject,BindingResult result)
	{
		boolean flag=false;
		
		
		//Check of errors.
		if(result.hasErrors())
		{
			return new ModelAndView("AddAsset");
		}

		//Setting Avaliable copies to number of copies
		assetObject.setAvailable(assetObject.getCopies());
		
		//Generate books based on number of copies in assetObject		
		List<AssetList> listOfBooks=new ArrayList<AssetList>();
		for(int i=0;i<assetObject.getCopies();i++)
		{
			AssetList book=new AssetList();
			book.setIsbn(assetObject.getIsbn());
			book.setType(assetObject.getAssettype());
			listOfBooks.add(book);
		}
		
		//Sending asset(Book) to DataBase for saving
		//It return true on successful Insertion vice versa.
		flag=assetAddEditDeleteService.AddAsset(assetObject, listOfBooks);
		
		//check if Asset(Book) has been inserted successfully or not.
		if(flag)
		{
			
			return new ModelAndView("AddAsset","message","Asset Added Successfully");
		}
		else
		{
			return new ModelAndView("AddAsset","message","Failed to Added");
		}
		
	}
	
	
	@RequestMapping(value="/editAsset",method=RequestMethod.GET)
	public ModelAndView editAsset()
	{
		System.out.println("inside editAsset");
		//Asset asset=assetAddEditDeleteService.editAsset(assetId);
		return new ModelAndView("");
	}
	
	
	@RequestMapping(value="/deleteasset",method=RequestMethod.POST)
	public ModelAndView deleteAsset(@RequestParam("patronid") int assetId)
	{
		System.out.println("inside editAsset"+assetId);
		assetAddEditDeleteService.deleteAsset(assetId);
			
		return new ModelAndView("");
	}
	
	
	
	
	
}
