package com.indus.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.indus.model.CheckOut;
import com.indus.service.CheckOutService;
import com.indus.service.LoginService;
import com.indus.util.BookOperations;
import com.indus.util.GetCurrentDateTime;

@Controller
public class CheckOutController
{
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	CheckOutService checkOutService;
	
	@RequestMapping(value="/checkid",method=RequestMethod.POST)
	public ModelAndView checkpatron(@RequestParam("patronId") String patronId)
	{
		System.out.println(patronId);
		
		if(loginService.checkUser(patronId)== null)
		{
			return new ModelAndView("IssueBook", "error", "Invalid PatronId");
		}
		else
		{
			return new ModelAndView("issuebook2", "id", patronId);
		}
	}
	
	@RequestMapping(value="/checkout",method=RequestMethod.POST)
	public ModelAndView checkOutBook(@RequestParam("patronId")String patronId,@RequestParam("assetId")int assetId,@RequestParam("assettype")String assetType)
	{
		System.out.println("inside checkout controller");
	//	java.util.Date dt = new java.util.Date();
		
	//	java.util.Date returndate = new java.util.Date();
		
		//returndate.setDate(dt.getDate()+20);
		
		CheckOut checkOut=new CheckOut(patronId,assetId,GetCurrentDateTime.getCurrentDate(),GetCurrentDateTime.addDays(GetCurrentDateTime.getCurrentDate(), BookOperations.getDays(assetType)));
		
		boolean falg=checkOutService.checkOutDetailes(checkOut);
		
	
		return null;
	}
	
	
}
