package com.indus.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.indus.model.Asset;
import com.indus.model.User;
import com.indus.service.ListAssetService;
import com.indus.service.LoginService;


@Controller
public class LoginController
{
	@Autowired
	ListAssetService listServiceImpl;
	
	@Autowired
	ListAssetService listAssetService; 
	
	@Autowired
	LoginService loginService;
	
	@RequestMapping(value="/check",method=RequestMethod.POST)
	public ModelAndView validate(@RequestParam("patronid") String patronid,@RequestParam("password") String password)
	{
		
		
		User user=loginService.checkUser(patronid);
		

		if(user.getPatronid().equals(patronid) && user.getPassword().equals(password))
		{
			String role=user.getRole();
			if(role.equals("admin") || role.equals("librarian"))
			{
				ModelAndView view= new ModelAndView("adminpageTest");
				List<Asset> listOfAssets=listServiceImpl.listAssets();
				view.addObject("listOfAssets",listOfAssets);
				view.addObject("userobj", user.getUsername());
				return view;
			}
			else 
			{
				List<Asset> listAssets=listAssetService.listAssets();
				ModelAndView view= new ModelAndView("studentpage");
				view.addObject("userobj", user.getUsername());
				view.addObject("assetlist", listAssets);
				return view;
			}
			
		}
			else
				return new ModelAndView("error");
	}	
}