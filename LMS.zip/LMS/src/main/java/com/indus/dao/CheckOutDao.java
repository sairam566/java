package com.indus.dao;

import com.indus.model.CheckOut;

public interface CheckOutDao 
{
	public void addCheckOutBook(CheckOut checkOut);
}
