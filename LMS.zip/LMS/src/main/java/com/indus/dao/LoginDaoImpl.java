package com.indus.dao;

import java.util.List;


import org.hibernate.Session;

import com.indus.model.User;




public class LoginDaoImpl implements LoginDao
{
	
	public Session session;

	public LoginDaoImpl(Session session) 
	{
		super();
		this.session = session;
	}
	
	public User checkUser(String patronid) 
	{
		System.out.println("In daoimpl");
		System.out.println(patronid);

		// List<User> ll=session.createQuery("from User").list();
		User user = (User) session.get(User.class, patronid);
		System.out.println(user.getDateofbirth());
		return user;

	}
	
	
	
}
