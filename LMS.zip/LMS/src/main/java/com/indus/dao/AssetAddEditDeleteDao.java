package com.indus.dao;

import java.util.List;

import com.indus.model.Asset;
import com.indus.model.AssetList;

public interface AssetAddEditDeleteDao 
{
	public void addAssetToDB(Asset asset,List<AssetList> listOfBooks);
	
	public Asset getAssetDetailes(int assetId);
	
	public boolean deleteAssetDetailes(int assetId);
}
