package com.indus.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.indus.model.Asset;
import com.indus.model.AssetList;

public class AssetDaoImpl implements AssetDao 
{
	public Session session;

	public AssetDaoImpl(Session session)
	{
		this.session=session;
	}

	public boolean addAsset(Asset a,List<AssetList> assetLists) throws HibernateException
	{
		//System.out.println(a.getAssettype() + " " + a.getAuthor() + " "+a.getIsbn() + " " +a.getTitle()+ "avilable " +a.getAvailable()+"copies"+a.getCopies());
		
		session.save(a);
		for (AssetList assetList : assetLists) 
		{
			session.save(assetList);
		}
		return true;
		
	}

}
