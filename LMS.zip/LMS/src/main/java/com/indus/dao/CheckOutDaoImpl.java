package com.indus.dao;

import org.hibernate.Session;

import com.indus.model.CheckOut;

public class CheckOutDaoImpl implements CheckOutDao {

	public Session session;
	
	
	
	public CheckOutDaoImpl(Session session) {
		super();
		this.session = session;
	}



	public void addCheckOutBook(CheckOut checkOut) 
	{
		
		session.save(checkOut);
		
		
	}

}
