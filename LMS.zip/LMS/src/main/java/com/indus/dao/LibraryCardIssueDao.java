package com.indus.dao;

import com.indus.model.IssueLibCard;

public interface LibraryCardIssueDao 
{
	public boolean setLibraryCard(IssueLibCard card);
}
