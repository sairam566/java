package com.indus.dao;



import com.indus.model.User;

public interface LoginDao
{
		public User checkUser(String username);
}
