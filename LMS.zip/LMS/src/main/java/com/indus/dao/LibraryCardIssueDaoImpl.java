package com.indus.dao;

import org.hibernate.Session;

import com.indus.model.IssueLibCard;

public class LibraryCardIssueDaoImpl implements LibraryCardIssueDao 
{
	public Session session;
	
	public LibraryCardIssueDaoImpl(Session session)
	{
		this.session=session;
	}
	
	
	
	public boolean setLibraryCard(IssueLibCard card) 
	{
		System.out.println(card.getAddress()+"----->Address");
		System.out.println(card.getDateOfBirth()+"----->date");
		session.save(card);
		return false;
	}

}
