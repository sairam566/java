package com.indus.dao;

import java.util.List;

import com.indus.model.Asset;

public interface ListAssetDao
{
	public List<Asset> listAssets();
}
