package com.indus.dao;

import org.hibernate.Session;

public class DaoFactory 
{
	
	public static LoginDao getLoginDao(Session session)
	{
		
		LoginDao loginDao=new LoginDaoImpl(session);
		
		return loginDao;
		
	}
	
	public static LibraryCardIssueDao getLibraryCardIssueDaoImpl(Session session)
	{
		
		LibraryCardIssueDao libraryCardIssueDao=new LibraryCardIssueDaoImpl(session);
		
		return libraryCardIssueDao;
		
	}
	
	
	
	public static AssetAddEditDeleteDao getAssetAddEditDeleteDao(Session session)
	{
		AssetAddEditDeleteDao assetAddEditDeleteDao=new AssetAddEditDeleteDaoImpl(session);
		
		return assetAddEditDeleteDao;
	}
	
	public static AssetDao getAddAssetDao(Session session)
	{
		
		AssetDao addAssetDao=new AssetDaoImpl(session);
		
		return addAssetDao;
		
	}
	public static ListAssetDao getListAssetDao(Session session)
	{
		
		ListAssetDao listAssetDao=new ListAssetDaoImpl(session);
		
		return listAssetDao;
		
	}
	
	public static CheckOutDao getCheckOutDaoObj(Session session)
	{
		return new CheckOutDaoImpl(session);
	}
	
}
