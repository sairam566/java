package com.indus.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import com.indus.model.Asset;
import com.indus.model.AssetList;


public class AssetAddEditDeleteDaoImpl implements AssetAddEditDeleteDao 
{
	
	public Session session;
	
	public AssetAddEditDeleteDaoImpl(Session session)
	{
	
		this.session = session;
	}

	public void addAssetToDB(Asset assetObject,List<AssetList> listOfBooks) throws HibernateException
	{
		
		//Save the Asset(book) to asset(DataBaseTablename) table
		//check if object is not null
		if(assetObject!=null)
		{
			session.save(assetObject);
		}
		
		//Save the listOfBooks to assetlist table
		for (AssetList book : listOfBooks) 
		{
			session.save(book);
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	public Asset getAssetDetailes(int assetId)  throws HibernateException
	{
		
		return null;
	}

	public boolean deleteAssetDetailes(int assetId) throws HibernateException
	{
		
		return false;
	}

	

}
