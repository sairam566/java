package com.indus.dao;

import java.util.List;

import org.hibernate.Session;

import com.indus.model.Asset;

public class ListAssetDaoImpl implements ListAssetDao
{
	public Session session;
	public ListAssetDaoImpl(Session session)
	{
		this.session=session;
	}
	public List<Asset> listAssets() 
	{
			return session.createQuery("from Asset").list();
	}

}
