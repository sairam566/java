package com.indus.service;

import com.indus.model.CheckOut;

public interface CheckOutService 
{
	public boolean checkOutDetailes(CheckOut checkOut);
	
	
}
