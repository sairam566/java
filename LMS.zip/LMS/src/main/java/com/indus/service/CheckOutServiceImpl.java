package com.indus.service;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import com.indus.dao.CheckOutDao;
import com.indus.dao.DaoFactory;
import com.indus.model.CheckOut;
import com.indus.util.HibernateUtil;

@Component
public class CheckOutServiceImpl implements CheckOutService 
{

	public SessionFactory sessionFactory;
	public Session session;
	public Transaction transaction;
	
	private CheckOutDao checkOutDao;
	
	public boolean checkOutDetailes(CheckOut checkOut) 
	{
		session=HibernateUtil.buildSession();
		
		checkOutDao=DaoFactory.getCheckOutDaoObj(session);
		
		Transaction tx=session.beginTransaction();
		
		boolean flag=false;
		try
		{
			checkOutDao.addCheckOutBook(checkOut);
			flag=true;
			tx.commit();
		}
		catch(HibernateException e)
		{
			tx.rollback();
			flag=false;
			e.printStackTrace();	
		}
		
		return flag;
	}

}
