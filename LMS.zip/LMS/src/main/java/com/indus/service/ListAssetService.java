package com.indus.service;

import java.util.List;


import com.indus.model.Asset;

public interface ListAssetService
{
	public List<Asset> listAssets();
}
