package com.indus.service;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import com.indus.dao.DaoFactory;
import com.indus.dao.LoginDao;
import com.indus.model.User;
import com.indus.util.HibernateUtil;




@Component
public class LoginServiceImpl implements LoginService
{
	SessionFactory sessionFactory;
	public  Session session;
	public  Transaction transaction;
	private LoginDao loginDaoImpl;
	
	



	public User checkUser(String patronid)
	{

		session=HibernateUtil.buildSession();
		
		
		loginDaoImpl=DaoFactory.getLoginDao(session);
		
		Transaction tx=session.beginTransaction();
		User user=null;
		try
		{
			user=loginDaoImpl.checkUser(patronid);
			tx.commit();
		}
		catch(HibernateException e)
		{
			tx.rollback();
		
			e.printStackTrace();	
		}
		
			
		return user;
	}

}
