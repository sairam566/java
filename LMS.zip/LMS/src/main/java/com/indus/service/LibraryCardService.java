package com.indus.service;

import com.indus.model.IssueLibCard;

public interface LibraryCardService
{
	public boolean putLibraryCard(IssueLibCard card);
}
