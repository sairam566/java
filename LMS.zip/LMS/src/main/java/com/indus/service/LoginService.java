package com.indus.service;

import java.util.List;



import com.indus.model.User;


public interface LoginService 
{
	
	public User checkUser(String patronid);
	
	
}
