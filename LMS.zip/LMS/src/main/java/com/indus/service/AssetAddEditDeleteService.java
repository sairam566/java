package com.indus.service;

import java.util.List;

import com.indus.model.Asset;
import com.indus.model.AssetList;

public interface AssetAddEditDeleteService
{
	public boolean AddAsset(Asset asset,List<AssetList> booksList);
	
	public Asset editAsset(int assetId);
	
	public boolean deleteAsset(int assetId);
	
	
}
