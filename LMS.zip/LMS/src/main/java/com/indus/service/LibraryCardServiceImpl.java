package com.indus.service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import com.indus.dao.DaoFactory;
import com.indus.dao.LibraryCardIssueDao;
import com.indus.model.IssueLibCard;
import com.indus.util.HibernateUtil;

@Component
public class LibraryCardServiceImpl implements LibraryCardService
{

	SessionFactory sessionFactory;
	public  Session session;
	public  Transaction transaction;
	private LibraryCardIssueDao libraryCardIssueDao;
	
	
	public boolean putLibraryCard(IssueLibCard card) 
	{
		session=HibernateUtil.buildSession();
		
		 libraryCardIssueDao=DaoFactory.getLibraryCardIssueDaoImpl(session);
		 
		 Transaction tx=session.beginTransaction();
		 
		 boolean flag=false;
			try
			{
				flag=libraryCardIssueDao.setLibraryCard(card);
				tx.commit();
			}
			catch(HibernateException e)
			{
				tx.rollback();
			
				e.printStackTrace();	
			}
		 
		 
		return flag;
	}

}
