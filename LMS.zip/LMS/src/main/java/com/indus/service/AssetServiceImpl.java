package com.indus.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import com.indus.dao.AssetDao;
import com.indus.dao.DaoFactory;
import com.indus.model.Asset;
import com.indus.model.AssetList;
import com.indus.util.HibernateUtil;

@Component
public class AssetServiceImpl implements AssetService
{
	SessionFactory sessionFactory;
	public  Session session;
	public  Transaction transaction;
	
	private AssetDao assetDaoImpl;

	public boolean addAsset(Asset a,List<AssetList> assetLists) 
	{
		session=HibernateUtil.buildSession();
		
		assetDaoImpl=DaoFactory.getAddAssetDao(session);
		
		Transaction tx=session.beginTransaction();
		
		Boolean b=false;
		try
		{
			b=	assetDaoImpl.addAsset(a,assetLists);
			tx.commit();
			
		}
		catch(HibernateException e)
		{
			e.printStackTrace();
			tx.rollback();
		}
		return b;
	}

}
