package com.indus.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;

import com.indus.dao.DaoFactory;
import com.indus.dao.ListAssetDao;
import com.indus.model.Asset;
import com.indus.util.HibernateUtil;

@Component
public class ListAssetServiceImpl implements ListAssetService
{
	SessionFactory sessionFactory;
	public  Session session;
	public  Transaction transaction;
	
	private ListAssetDao listAssetDaoImpl;
	
	public List<Asset> listAssets()
	{
		
		session=HibernateUtil.buildSession();
		
		listAssetDaoImpl=DaoFactory.getListAssetDao(session);
		Transaction tx=session.beginTransaction();
		List<Asset> l=null;
		try
		{
			l=listAssetDaoImpl.listAssets();
			tx.commit();
		}
		catch(HibernateException e)
		{
			tx.rollback();
		
			e.printStackTrace();	
		}
		
		return l;
	}
	
}
