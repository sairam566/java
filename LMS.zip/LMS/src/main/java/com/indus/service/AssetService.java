package com.indus.service;

import java.util.List;

import com.indus.model.Asset;
import com.indus.model.AssetList;

public interface AssetService 
{
	public boolean addAsset(Asset a, List<AssetList> assetLists);
}
