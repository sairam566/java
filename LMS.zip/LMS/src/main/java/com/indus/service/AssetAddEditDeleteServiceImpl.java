package com.indus.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Component;
import com.indus.dao.AssetAddEditDeleteDao;
import com.indus.dao.DaoFactory;
import com.indus.model.Asset;
import com.indus.model.AssetList;
import com.indus.util.HibernateUtil;

@Component
public class AssetAddEditDeleteServiceImpl implements AssetAddEditDeleteService 
{
	SessionFactory sessionFactory;
	public  Session session;
	public  Transaction transaction;
	private AssetAddEditDeleteDao assetAddEditDeleteDao;
	
	public boolean AddAsset(Asset asset,List<AssetList> listOfBooks) 
	{
		session=HibernateUtil.buildSession();
		
		assetAddEditDeleteDao=DaoFactory.getAssetAddEditDeleteDao(session);
		
		Transaction tx=session.beginTransaction();
		
		boolean flag=false;
		try
		{
			assetAddEditDeleteDao.addAssetToDB(asset,listOfBooks);
			tx.commit();
			flag=true;
		}
		catch (HibernateException e)
		{
			tx.rollback();
			e.printStackTrace();	
		}
		finally
		{
			session.close();
		}
		return flag;
	}
	
	public Asset editAsset(int assetId)
	{
		
		session=HibernateUtil.buildSession();
		
		assetAddEditDeleteDao=DaoFactory.getAssetAddEditDeleteDao(session);
		
		Transaction tx=session.beginTransaction();
		
		System.out.println("inside editdelete service"+assetId);
		System.out.println("inside editMethod service class");
		
		Asset asset=null;
		try
		{
			asset=assetAddEditDeleteDao.getAssetDetailes(assetId);
			tx.commit();
		}
		catch (HibernateException e)
		{
			tx.rollback();
			e.printStackTrace();	
		}
		finally
		{
			session.close();
		}
		
		return asset;
	}

	public boolean deleteAsset(int assetId) 
{
		
		session=HibernateUtil.buildSession();
		
		assetAddEditDeleteDao=DaoFactory.getAssetAddEditDeleteDao(session);
		
		Transaction tx=session.beginTransaction();
		
		System.out.println("inside editdelete service class"+assetId);
		System.out.println("inside deleteMethod service class");
		
		boolean flag=false;
		try
		{
			flag=assetAddEditDeleteDao.deleteAssetDetailes(assetId);
			tx.commit();
		}
		catch (HibernateException e)
		{
			tx.rollback();
			e.printStackTrace();	
		}
		finally
		{
			session.close();
		}	
		return flag;
	}
}
