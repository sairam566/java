package com.indus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="login")
public class User 
{
	@Id
	@Column(name="patronid")
	private String patronid;
	
	@Column(name="username")
	private String username;
	
	@Column(name="address")
	private String address;
	
	@Column(name="mobile")
	private String mobile;
	
	@Column(name="dateofbirth")
	private String dateofbirth;
	
	@Column(name="password")
	private String password;

	@Column(name="role")
	private String role;
	
	@Column(name="assetstaken")
	private int assetstaken;
	
	
	public String getPatronid() {
		return patronid;
	}
	public void setPatronid(String patronid) {
		this.patronid = patronid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getDateofbirth() {
		return dateofbirth;
	}
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getAssetstaken() {
		return assetstaken;
	}
	public void setAssetstaken(int assetstaken) {
		this.assetstaken = assetstaken;
	}
	public String getUsername()
	{
		return username;
	}
	public void setUsername(String username)
	{
		this.username = username;
	}
	public String getPassword()
	{
		return password;
	}
	public void setPassword(String password) 
	{
		this.password = password;
	}
}
