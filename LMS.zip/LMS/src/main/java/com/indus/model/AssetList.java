package com.indus.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="assetlist")
public class AssetList 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="assetid")
	private  int assetid;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Column(name="isbn")
	private String isbn;
	
	@Column(name="type")
	private String type;
	
	@OneToMany
	private List<Asset> alist;
	
	public int getAssetid() 
	{
		return assetid;
	}
	public void setAssetid(int assetid)
	{
		this.assetid = assetid;
	}
	public String getIsbn() 
	{
		return isbn;
	}
	public void setIsbn(String isbn)
	{
		this.isbn = isbn;
	}
	
	
}
