package com.indus.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="checkout")
public class CheckOut 
{
	@Id
	@Column(name="assetid")
	private int assetid;
	
	@Column(name="patronid")
	private String patronid;
	
	@Column(name="issuedate")
	private Date issuedate;
	
	@Column(name="returndate")
	private Date returndate;
	
	
	
	public CheckOut() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CheckOut(String patronid, int assetid, Date issuedate, Date returndate) {
		super();
		this.patronid = patronid;
		this.assetid = assetid;
		this.issuedate = issuedate;
		this.returndate = returndate;
	}
	public String getPatronid() {
		return patronid;
	}
	public void setPatronid(String patronid) {
		this.patronid = patronid;
	}
	public int getAssetid() {
		return assetid;
	}
	public void setAssetid(int assetid) {
		this.assetid = assetid;
	}
	public Date getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(Date issuedate) {
		this.issuedate = issuedate;
	}
	public Date getReturndate() {
		return returndate;
	}
	public void setReturndate(Date returndate) {
		this.returndate = returndate;
	}
	
	
}
