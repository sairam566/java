package com.indus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="asset")
public class Asset 
{
	@NotNull(message="should not be empty")
	@Pattern(regexp="[0-9]+(?:-[0-9]+)?(,[0-9]+(?:-[0-9]+)?)*",message="Not a valid ISBN")
	@Id
	@Column(name="isbn")
	private String isbn=null;
	
	
	@NotBlank(message="Select an Asset Type")
	@Column(name="assettype")
	private String assettype=null;
	
	@NotNull(message="Should not be Empty")
	@Size(min=3,message="should be more than 3 charachers")
	@Column(name="title")
	private String title=null;
	
	
	@NotBlank(message="should not be empty")
	@Size(min=3,message="should be more than 3 charachers")
	@Column(name="author")
	private String author=null;
	
	
	@Min(value=1,message="should be more than one")
	@Column(name="copies")
	private int copies;
	
	
	@Column(name="available")
	private int available;
	
	public String getAssettype() {
		return assettype;
	}
	public void setAssettype(String assettype) {
		this.assettype = assettype;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public int getCopies() {
		return copies;
	}
	public void setCopies(int copies) {
		this.copies = copies;
	}
	public int getAvailable() {
		return available;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
	
}
