package com.indus.model;



import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.NumberFormat;
import org.springframework.format.annotation.NumberFormat.Style;

@Entity
@Table(name="login")
public class IssueLibCard 
{
	
	@NotNull(message="should not be Empty")
	@Size(min=10,message="should enter proper Email-Id")
	@Pattern(regexp="[A-Za-z0-9._%-+]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}",message="Not a valid EmailId")
	
	@Id
	@Column(name="patronid")
	private String email=null;
	
	
	
	@NotNull(message="should not be Empty")
	@Size(min=3,message="should be more than 4 charachers")
	@Column(name="username")
	private String name=null;
	
	
	
	@NotNull(message="should not be Empty")
	@Size(min=3,message="should be atleast 4 charachers lenght")
	@Column(name="password")
	private String password=null;
	
	@NotNull(message="should not be Empty")
	@Size(min=3,message="should provide a proper address")
	@Column(name="address")
	private String address=null;
	
	@NotNull(message="should not be Empty")
	@Length(max=10,min=10,message="Phone number is not valid. Should be of length 10.")
	@NumberFormat(style= Style.NUMBER)
	@Column(name="mobile")
	private String mobile=null;
	
	@NotNull(message="should not be Empty select user Type")
	@Column(name="role")
	private String userType=null;
	
	@Basic
	@Temporal(TemporalType.DATE)
	@Column(name="dateofbirth")
	private java.util.Date dateOfBirth;

	@Column(name="assetstaken")
	private int assetstaken;
	

	

	public IssueLibCard() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setDateOfBirth(java.util.Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	
	
	public java.util.Date getDateOfBirth() {
		return dateOfBirth;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	
	
	
	
	
}
